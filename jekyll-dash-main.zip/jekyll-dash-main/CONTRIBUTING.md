Thank you for contributing to jeyll-dash. Feel free to fork this repository and raise a pull request. 
